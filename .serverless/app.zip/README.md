## Notes

-   Probably monolith application
-   I will deploy the application as a serverless application, on an AWS Lambda, using Bref (bref.sh)
-   try to use threeJS
