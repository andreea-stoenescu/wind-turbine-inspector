## Notes

-   Probably monolith application
-   I will deploy the application as a serverless application, on an AWS Lambda, using Bref (bref.sh)
-   try to use threeJS

## URL

https://4ru379m2j3.execute-api.us-east-1.amazonaws.com
